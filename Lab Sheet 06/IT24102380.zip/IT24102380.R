setwd("C:\\Users\\Lenovo\\Desktop\\IT24102380")

##01
##Binomial Distribution
#here, random variable X has binomial distribution with n =50 and p = 0.85
1 - pbinom(46, 50, 0.85)


##02
##Number of calls received in  an hour
##Poisson distribution
##here, random variable X has poisson distribution with lambda = 12 
dpois(15, 12)